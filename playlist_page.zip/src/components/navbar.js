import React, {Component} from 'react';


const Navbar = () =>{
    return (
<nav className="navbar navbar-light">

<a className="navbar-brand" href="#">
<img className="logo-img" src="../assets/logo-white.png"/>
 
</a>
<h4 className="navbarText"> Action Sports Video Playlist </h4>

</nav>
    )

}

export default Navbar;